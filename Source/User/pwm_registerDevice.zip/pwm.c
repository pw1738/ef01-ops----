/*******************************************************************************
        (c) COPYRIGHT 2010-2018 by Efficient Systems, Inc.    
                          All rights reserved.
    
       This software is confidential and proprietary to Efficient 
     Systems, Inc.  No part of this software may be reproduced,    
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement    
     between Efficient Systems and its licensee.
 FileName    : pwm.c
 Author      : ranwei
 Version     : 
 Date        : 2016/2/19 16:9:8:452
 Description : 
 Others      : 

 History      :
  1.Date         -- 2016/2/19 16:9:8:452
    Author       -- ranwei
    Modification -- Created file

*******************************************************************************/
    
#define  PWM_GLOBAL

/* includes-------------------------------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
#include "stm32f10x.h"
#include "pwm.h"
    
/* Private typedef&macro&definde----------------------------------------------*/
#define SZ_PWM_DEVICE_NUM  2





/* Private variables ---------------------------------------------------------*/
ST_PWM_Device_Type g_astPWMDeviceArray[SZ_PWM_DEVICE_NUM] = {0};




/* Private functions ---------------------------------------------------------*/
static void _PWM_Init(ST_PWM_Device_Type *pDev);
static void _PWM_SetLevel(ST_PWM_Device_Type *pDev, uint8_t level);



/* External functions --------------------------------------------------------*/
/* External variables --------------------------------------------------------*/
    
ST_PWM_Device_Type* PWM_Register(uint32_t timerCLK, uint32_t gpioCLK, uint16_t gpioPin, GPIO_TypeDef *gpioPort, TIM_TypeDef *timX, uint8_t timChNum)
{
    int iLoop;
    ST_PWM_Device_Type *pDev = NULL;
    
    for(iLoop = 0; iLoop < SZ_PWM_DEVICE_NUM; iLoop++)
    {
        if(0 == g_astPWMDeviceArray[iLoop].bIsDeviceActive)
        {
            pDev = &g_astPWMDeviceArray[iLoop];
        }
    }

    if(NULL == pDev)
    {
        return NULL;
    }

    pDev->bIsDeviceActive = 1;
    pDev->gpioCLK = gpioCLK;
    pDev->gpioPin = gpioPin;
    pDev->gpioPort = gpioPort;
    pDev->timChNum = timChNum;
    pDev->timerCLK = timerCLK;
    pDev->timX = timX;
    pDev->Init = _PWM_Init;
    pDev->SetLevel = _PWM_SetLevel;

    return pDev;
}

static void _PWM_Init(ST_PWM_Device_Type *pDev)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    /* TIM clock enable */
    switch(pDev->timerCLK)
    {
        case RCC_APB2Periph_TIM1:
        case RCC_APB2Periph_TIM8:
            RCC_APB2PeriphClockCmd(pDev->timerCLK, ENABLE);
            break;
        case RCC_APB1Periph_TIM2:
        case RCC_APB1Periph_TIM3:
        case RCC_APB1Periph_TIM4:
        case RCC_APB1Periph_TIM5:
            RCC_APB1PeriphClockCmd(pDev->timerCLK, ENABLE);
            break;
    }

    /* GPIO clock enable */
    RCC_APB2PeriphClockCmd(pDev->gpioCLK, ENABLE);
    
    /* GPIO Configuration:TIM Channel as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = pDev->gpioPin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(pDev->gpioPort, &GPIO_InitStructure);   

    TIM_DeInit(pDev->timX);    //set timer to default value 
}


/*******************************************************************************
 Prototype    : PWM_Set
 Description  : 
 Input        : timX -- pwm��ʱ��.
                timChNum -- pwmͨ����.
                level -- pwm�ȼ���0~100������0�����ر�pwm.
 Output       : 
 Return Value : 
 Calls        : 
 Called By    : 
 
 History      :
  1.Date         -- 2016/2/22 9:17:33:790
    Author       -- ranwei
    Modification -- Created function

*******************************************************************************/
static void _PWM_SetLevel(ST_PWM_Device_Type *pDev, uint8_t level)
{ 
    uint16_t pluse = 0;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;   //Define the basic configuration struct
    TIM_OCInitTypeDef  TIM_OCInitStructure;    // Define the channel 
    //	TIM_BDTRInitTypeDef TIM_BDTRInitStructure;  //

    //TIM_InternalClockConfig(TIM1);     //initial TIM3 clock

    //The basic configuration of timer
    TIM_TimeBaseStructure.TIM_Period =14400;//����ֵΪ1000 1000-1    configure the duty ratio of the pwm
    TIM_TimeBaseStructure.TIM_Prescaler = 499;//3��Ƶ  3-1   499
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;//������Ƶ0   TIM_CKD_DIV1
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//���ϼ���
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0; //
    TIM_TimeBaseInit(pDev->timX, &TIM_TimeBaseStructure);

    TIM_ARRPreloadConfig(pDev->timX, ENABLE); 

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    //TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;//TIM����Ƚϼ��Ը�
    //TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High; //	
    if(0 == level)
    {
        pluse = 1;
	    
    }
    else
    {
        pluse = 144*level;
    }
    TIM_OCInitStructure.TIM_Pulse = pluse;

    switch(pDev->timChNum)
    {
        case 1:
            TIM_OC1Init(pDev->timX, &TIM_OCInitStructure);
            TIM_OC1PreloadConfig(pDev->timX, TIM_OCPreload_Enable);             
            break;
        case 2:
            TIM_OC2Init(pDev->timX, &TIM_OCInitStructure);
            TIM_OC2PreloadConfig(pDev->timX, TIM_OCPreload_Enable);             
            break;
        case 3:
            TIM_OC3Init(pDev->timX, &TIM_OCInitStructure);
            TIM_OC3PreloadConfig(pDev->timX, TIM_OCPreload_Enable);             
            break;
        case 4:
            TIM_OC4Init(pDev->timX, &TIM_OCInitStructure);
            TIM_OC4PreloadConfig(pDev->timX, TIM_OCPreload_Enable);             
            break;
        default:
            break;
    }


	TIM_Cmd(pDev->timX, ENABLE);//ʹ�ܶ�ʱ��2	
	
	TIM_CtrlPWMOutputs(pDev->timX, ENABLE);  //
}


    
/**************** (C) COPYRIGHT 2010-2018 Efficient *****END OF FILE***********/
