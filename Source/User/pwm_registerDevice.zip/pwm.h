/*******************************************************************************
        (c) COPYRIGHT 2010-2018 by Efficient Systems, Inc.    
                          All rights reserved.
    
       This software is confidential and proprietary to Efficient 
     Systems, Inc.  No part of this software may be reproduced,    
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement    
     between Efficient Systems and its licensee.
 FileName    : pwm.h
 Author      : ranwei
 Version     : 
 Date        : 2016/2/19 16:8:51:85
 Description : 
 Others      : 

 History      :
  1.Date         -- 2016/2/19 16:8:51:85
    Author       -- ranwei
    Modification -- Created file

*******************************************************************************/
#ifndef __PWM_H__
#define __PWM_H__

#ifdef __cplusplus
extern "C"{
#endif /* __cplusplus */

#ifdef  PWM_GLOBAL
#define PWM_EXT
#else
#define PWM_EXT extern
#endif /* PWM_GLOBAL */

/*============================================================================*/
/*                                  @INCLUDES                                 */
/*============================================================================*/
#include <stdint.h>
#include "stm32f10x.h"


/*============================================================================*/
/*                              @MACROS & @TYPEDEFS                           */
/*============================================================================*/
#pragma pack(push, 1)

typedef struct{
    uint8_t bIsDeviceActive : 1;
    uint8_t level : 7;
    uint32_t timerCLK;
    uint32_t gpioCLK;
    uint16_t gpioPin;
    GPIO_TypeDef *gpioPort;
    TIM_TypeDef *timX; 
    uint8_t timChNum;
    
    void (*Init)(ST_PWM_Device_Type *pDev);
    void (*SetLevel)(ST_PWM_Device_Type *pDev, uint8_t level);
}ST_PWM_Device_Type;



#pragma pack(pop)



/*============================================================================*/
/*                               @GLOBAL VIRIABLES                            */
/*============================================================================*/

/*============================================================================*/
/*                                    @FUNCS                                  */
/*============================================================================*/
void PWM_Set(TIM_TypeDef *timX, uint8_t timChNum, uint8_t level);
void PWM_Init(uint32_t timerCLK, uint32_t gpioCLK, uint16_t gpioPin, GPIO_TypeDef *gpioPort);



#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __PWM_H__ */
/**************** (C) COPYRIGHT 2010-2018 Efficient *****END OF FILE***********/
